CKEDITOR.plugins.setLang( 'pdfuploads', 'ru',
    {
        addFile : 'Добавить файл',
        addImage: 'Добавить изображение',
        processing: 'Обработка...',
        fileTooBig : 'Недопустимый размер файла, выберите файл меньшего размера.',
        invalidExtension : 'Недопустимый тип файла, выберите файл с допустимым разрешением.',
        nonAcceptedExtension: 'Недопустимый тип файла, выберите файл с допустимым разрешением:\r\n%0',
		nonImageExtension: 'Пожалуйста, выберите изображение',
		imageTooWide: 'Изображение слишком широкое',
		imageTooTall: 'Изображение слишком высокое'
    }
);
