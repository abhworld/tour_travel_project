CKEDITOR.plugins.setLang( 'pdfuploads', 'ar',
    {
        addFile : 'إضافة ملف',
        addImage: 'إضافة صورة',
        processing: ' جاري المعالجة...',
        fileTooBig : 'الملف كبير جداً، برجاء استخدام ملف أصغر.',
        invalidExtension: ' نوع الملف غير صالح، يرجى استخدام ملفات صالحة فقط.',
        nonAcceptedExtension: 'نوع الملف المستخدم غير صالح، يرجى استخدام ملفات صالحة فقط.:\r\n%0',
		// The file isn't an accepted type for images
		nonImageExtension: 'You must select an image',

		// The width of the image is over the allowed maximum
		imageTooWide: 'The image is too wide',

		// The height of the image is over the allowed maximum
		imageTooTall: 'The image is too tall'
    }
);

